<?php include'config.inc.php';
session_start(); //Iniciando sessão para uso da variável super global $_SESSION para exibição de alertas
?>
<!-- Função para confirmar se deseja excluir -->
<script language='javascript'>
    function confirmaExclusao(aURL) {
        if(confirm('Você tem certeza que deseja excluir?')) {
            location.href = aURL;
        }
    }
</script>
<!DOCTYPE html>
<html lang="br">
<head>
    <title>Catalogo Telefônico</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/estilo.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <?php include 'menu.php'; ?>
    <!-- Formulário para o filtro -->
 <form method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>"> <!-- Apontando para a mesma página -->
        <div class="col-md-3">
            <div class="form-group">              
                <input class="form-control"  placeholder="Pesquisar" name="filtro">       
            </div>
        </div>
        <div class="col-md-3">
            <input  type="submit" class="btn btn-info" value="Buscar"></input>
        </div>           
</form>    

<?php
include 'config.inc.php';
// Pegando filtro do input de pesquisa
$filtro = filter_input(INPUT_GET, "filtro");
    if($filtro){
        if($filtro!=" "){ //Veririfica se não esta em branco
                //SQL utilizando o IN para verificação de email e telefone, e LIKE com utilização do % no final para pesquisar nomes
                $sql = "SELECT * FROM cadastro WHERE '".$filtro."' IN (email, telefone) OR nome LIKE '".$filtro."%' ORDER BY nome ASC"; 
                $query = mysqli_query($conexao, $sql);

                if(@mysqli_num_rows($query) > 0){ // Verifico se o SQL retornou algum cadastro  
            ?>      
            
            <?php
                while($dados = mysqli_fetch_array($query)){ //loop para exibir na página os registros que foram encontrados
            ?>
        <table style="background: white;" class="table table-striped table-bordered table-hover">
            <thead>
                <tr class="text-center">
                    <th>Nome</th>
                    <th>Lagradouro</th>
                    <th>Numero</th>
                    <th>Bairro</th>
                    <th>Cidade</th>
                    <th>Estado</th>
                    <th>Telefone</th>
                    <th>Email</th>
                    <th>Sexo</th>
                    <th>Data Nascimento</th>
                    
                </tr>
            </thead>
            <tbody>
                
                <tr>
                    <td><?=$dados['nome'];?></td>
                    <td><?=$dados['lagradouro'];?></td>
                    <td><?=$dados['numero'];?></td>
                    <td><?=$dados['bairro'];?></td>
                    <td><?=$dados['cidade'];?></td>
                    <td><?=$dados['estado'];?></td>
                    <td><?=$dados['telefone'];?></td>
                    <td><?=$dados['email'];?></td>
                    <td><?=$dados['sexo'];?></td>
                    <td><?=$dados['dia'].'/'.$dados['mes'].'/'.$dados['ano'];?></td>       
                    <td><a class="btn btn-warning" href="alterarCT.php?&id_cadastro=<?=$dados['id_cadastro']; ?>">Alterar</a></td>
                    <td><a class="btn btn-danger" href="javascript:confirmaExclusao('excluirCT.php?&id_cadastro=<?=$dados['id_cadastro']; ?>')" class="ask">Excluir</a></td>
                    
                </tr>
            </tbody>
                 
        </table>
    
            <?php
                    }
                    
                }else{
            ?>
             <?php echo"<div class='alert alert-danger alert-dismissible fade show' role='alert'> <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> Nada encontrado para: <strong>".$filtro."</strong> </div>" ?>
                
            
            <?php
                }

            }else{
            }
    }else {
                $busca = "SELECT * FROM cadastro ORDER BY nome";
                $todos = mysqli_query($conexao, $busca);
    }


?>

<link href="css/bootstrap.css" rel="stylesheet">
 <?php
   include 'alertas.php';
 ?>    
<div class="panel-body">
    <div style="background: white;" class="table-responsive">
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr class="text-center">
                    <th>Nome</th>
                    <th>Telefone</th>
                    <th>Email</th>
                    
                </tr>
            </thead>
            <tbody>
                <!-- Array para exibição de todos os contatos na tela principal -->
                <?php 
                $busca = "SELECT * FROM cadastro ORDER BY nome";
                $todos = mysqli_query($conexao, $busca);
                while ($dados=mysqli_fetch_array($todos)) { ?>
                <tr>
                    <td><?=$dados['nome'];?></td>
                    <td><?=$dados['telefone'];?></td>
                    <td><?=$dados['email'];?></td>
                </tr>
               
                <?php } ?>
            </tbody>
        </table>
    </div>               
</div>

</div>   
    
    
    
</body>

    <footer>
      <div class="container">
        <div class="row">
            
          <div class="col-md-4">
            <span class="text-center"> Catalogo Telefônico.</span>
          </div>
          
          
        </div>
      </div>
    </footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="js/bootstrap.js"></script>

</html>