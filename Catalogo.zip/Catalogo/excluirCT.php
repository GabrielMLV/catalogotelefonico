<?php
session_start(); //Iniciando sessão para uso da variável super global $_SESSION para exibição de alertas
include 'config.inc.php';
	$id_cadastro = $_GET['id_cadastro'];

	$sql = "DELETE from cadastro WHERE id_cadastro = $id_cadastro";
	$deleta = mysqli_query($conexao, $sql);

	if(!$deleta){
	    echo "Ocorreu um erro ao deletar.<a href='index.php'> Voltar</a>";
	}else{
	   $_SESSION['deletado'] = "<div class='alert alert-success' role='alert'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Deletado com Sucesso!</div>";
            echo "<script>window.location.href='index.php'</script>";
	}

?>