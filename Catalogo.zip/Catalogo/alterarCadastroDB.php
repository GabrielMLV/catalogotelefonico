<?php
session_start(); //Iniciando sessão para uso da variável super global $_SESSION para exibição de alertas
include 'config.inc.php';
$id_cadastro = $_POST['id_cadastro'];
$nome = $_POST['nome'];
$lagradouro = $_POST['lagradouro'];
$numero = $_POST['numero'];
$bairro = $_POST['bairro'];
$cidade = $_POST['cidade'];
$estado = $_POST['estado'];
$telefone = $_POST['telefone'];
$email = $_POST['email'];
$sexo = $_POST['sexo'];
$dia = $_POST['dia'];
$mes = $_POST['mes'];
$ano = $_POST['ano'];

$emailConfirma = $_POST['emailConfirma'];

if($email == $emailConfirma){
$sql = "UPDATE cadastro SET nome='$nome', lagradouro='$lagradouro', numero='$numero', bairro='$bairro', cidade='$cidade', estado='$estado', telefone='$telefone', email='$email', sexo='$sexo', dia='$dia', mes='$mes', ano='$ano' WHERE id_cadastro=$id_cadastro";
$inserir = mysqli_query($conexao,$sql);

if(!$inserir){
    echo "Ocorreu um erro ao atualizar dados no banco de dados. <br>
    <a href='index.php'>Voltar</a>";
}else{
   $_SESSION['alterado_sucesso'] = "<div class='alert alert-success' role='alert'> <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> Alterado com Sucesso!</div>";
    echo "<script>window.location.href='index.php'</script>";
}
}else{
    $_SESSION['alterar_email_invalido'] = "<div class='alert alert-danger' role='alert'> <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Email digitado inválido. </div>";
    echo "<script>window.location.href='index.php'</script>";

}
?>